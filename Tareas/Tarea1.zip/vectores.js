var Vector3D = function(x,y,z){
			this.set(x,y,z);
		};

		Vector3D.prototype = {
			set:function(x,y,z){
				this.x=x;
				this.y=y;
				this.z=z;
				return this;
			}
		};
		var v = new Vector3D(1,0,0);

		function moduloV(){

			var x = v.x;
			var y = v.y;
			var z = v.z;
			
			var moduloV = (Math.sqrt((x*x)+(y*y)+(z*z)));
			
			return moduloV;
		}	

		function direccionV(){
			var modV = moduloV();
			var i = Math.round(v.x/mod * 180/ Math.PI) ;
			var j = Math.round(v.y/mod * 180/ Math.PI) ;;
			var k = Math.round(v.z/mod * 180/ Math.PI) ;;
			
			var direccionV = new Vector3D(i,j,k);
			
			return (direccionV);
		}

		document.write("El vector V es: "+JSON.stringify(v)+ "<div>");
		
		document.write("El Modulo del vector V es: "+JSON.stringify(moduloV())+ "<div>");
		document.write("Su direccion es: "+(JSON.stringify(direccionV()))+ "<div>");